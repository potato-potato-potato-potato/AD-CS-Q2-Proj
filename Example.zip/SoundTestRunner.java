import javax.swing.JFrame;

public class SoundTestRunner {

    public static void main(String args[]) {

        JFrame frame = new JFrame("SoundTest");

        SoundTest st = new SoundTest();
        frame.add(st);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

    }
}
